package GoormPBL.response;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResponseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResponseApplication.class, args);
	}

}
